# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

# import data to compute the distance
import pandas as pd
sp=pd.read_excel('shipping point.xls')
cl=pd.read_excel('customer locations1.xlsx')
import requests
from openpyxl import Workbook
def amap_time(o_lon, o_lat, d_lon, d_lat):
    o_lon,o_lat,d_lon,d_lat = map(float,[o_lon,o_lat,d_lon,d_lat])
    url = "http://restapi.amap.com/v3/direction/driving?key={key}&origin={origin}&destination={destination}&originid=&destinationid=&extensions=base&strategy=0&waypoints=&avoidpolygons=&avoidroad="
    key = "6828ea8c1670e149413299d8216c13eb" 
    origin = str(o_lon) + ',' + str(o_lat)
    destination = str(d_lon) + ',' + str(d_lat)
    url_temp = url.format(key = key, origin = origin, destination = destination)
    r = requests.get(url_temp)
    r = r.json()
    time = r['route']['paths'][0]['duration']
    dist = r['route']['paths'][0]['distance']
    return time, dist
sp_loc = []
cl_loc = []
excel_spcl=Workbook()
sheet=excel_spcl.active
sheet.cell(1,1).value='sp_lon'
sheet.cell(1,2).value='sp_lat'
sheet.cell(1,3).value='cl_lon'
sheet.cell(1,4).value='cl_lat'
sheet.cell(1,5).value='distance'
sheet.cell(1,6).value='duration'
row = 2
for i in range(len(sp)):
    lon = sp.loc[i,'lat']
    lat = sp.loc[i,'lon']
    sp_loc.append([lon,lat])
for i in range(len(cl)):
    lon = cl.loc[i,'lng']
    lat = cl.loc[i,'lat']
    cl_loc.append([lon,lat])
for i in range(len(sp_loc)):
    for j in range(len(cl_loc)):
        print('i:%i of sp:%i, j:%i of cl:%i'%(i,len(sp_loc),j,len(cl_loc)))
        t, d = amap_time(sp_loc[i][0], sp_loc[i][1], cl_loc[j][0], cl_loc[j][1])
        sheet.cell(row,1).value=sp_loc[i][0]
        sheet.cell(row,2).value=sp_loc[i][1]
        sheet.cell(row,3).value=cl_loc[j][0]
        sheet.cell(row,4).value=cl_loc[j][1]
        sheet.cell(row,5).value=d
        sheet.cell(row,6).value=t
        row += 1
excel_spcl.save("sp_cl32.xlsx")


