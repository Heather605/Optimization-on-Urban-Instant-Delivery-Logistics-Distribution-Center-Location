#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan 31 16:59:03 2019

@author: liwenye
"""
import pulp as pulp
from openpyxl import Workbook
def solve_ilp(objective , constraints) :
    print(objective)
    print(constraints)
    prob = pulp.LpProblem('LP1' , pulp.LpMinimize)
    prob += objective
    for cons in constraints :
        prob += cons
    print(prob)
    status = prob.solve()
    if status != 1 :
        return None
    else :
        return [v.varValue.real for v in prob.variables()]
    
import pandas as pd
sp_cl=pd.read_excel('sp_cl30.xlsx')

V_NUM1 = 79
#变量
variables1 = [pulp.LpVariable('X%d'%i , cat = pulp.LpBinary) for i in range(0 , V_NUM1)]
V_NUM2 = 232734
#这里y变量因为不会设置由i和j两个元素组成的下角标，所以按照普通方法从1标号
variables2 = [pulp.LpVariable('Y%d'%j , cat = pulp.LpBinary) for j in range(0 , V_NUM2)]

def f(x):
    if x <= 3600:
        y =  0
    else:
        y = 17.5
    return y

#目标函数
t=  sp_cl['duration']
d = sp_cl['d*h*c']
h = sp_cl['h']
objective = pulp.lpSum([d[j]*variables2[j] for j in range(0 , V_NUM2)]) + 57600*pulp.lpSum(variables1[i] for i in range(0 , V_NUM1))+ pulp.lpSum([h[j]*f(t[j])*variables2[j] for j in range(0 , V_NUM2)])

#约束条件
constraints = []

t = 2946
for j in range(0, t):
    sum=0
    n=0
    while n<=(V_NUM1-1):
        sum=sum+variables2[j+n*t]
        n=n+1
    constraints.append(sum==1)
    
i=0
while i<=(V_NUM1-1):
    for j in range(t*i , t*(i+1)):
      constraints.append(variables2[j]<=variables1[i])
    i=i+1

print(constraints)

res = solve_ilp(objective , constraints)
print(res)

excel_result=Workbook()
sheet=excel_result.active
sheet.cell(1,1).value='x'
sheet.cell(1,2).value='x-value'
sheet.cell(1,3).value='y'
sheet.cell(1,4).value='y-value'
row=2
for i in range(0 , V_NUM1):
    sheet.cell(row,1).value=i
    sheet.cell(row,2).value=variables1[i].value()
    row += 1
for j in range(0 , V_NUM2):
    if variables2[j].value()==1:
        sheet.cell(row,3).value=j
        sheet.cell(row,4).value=variables2[j].value()
        row += 1
excel_result.save("resulttest2.2.xlsx")
   
print("Total cost=",objective.value())

